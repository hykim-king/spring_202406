package com.pcwk.ehr.lombok;

import lombok.Data;

@Data //@Getter, @Setter, @ToString, @EqualsAndHashCode
public class Lombok02Test {
	private String name;
	private int age;
	
	public Lombok02Test() {}
	
	public Lombok02Test(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
	public static void main(String[] args) {
		Lombok02Test  main=new Lombok02Test();
		
		//setter
		main.setName("Lombok");
		main.setAge(1);
		
		//getter
		System.out.println("@Getter:"+main.getName());
		System.out.println("@Getter:"+main.getAge());	
		//ToString
		System.out.println("@Data:"+main);
		
		
		Lombok02Test  main02=new Lombok02Test("KIM",2);
		//getter
		System.out.println("@Getter:"+main02.getName());
		System.out.println("@Getter:"+main02.getAge());	
		//ToString
		System.out.println("@Data:"+main02);		


	}




}
